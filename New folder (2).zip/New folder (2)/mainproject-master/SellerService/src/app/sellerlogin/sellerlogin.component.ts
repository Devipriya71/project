import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Seller } from '../Seller';

@Component({
  selector: 'app-sellerlogin',
  templateUrl: './sellerlogin.component.html',
  styleUrls: ['./sellerlogin.component.css']
})
export class SellerloginComponent implements OnInit {

  

  ngOnInit(): void {
  }
  username:string;
  password:string;
   seller:Seller=new Seller();
  constructor( private router: Router) { }

  onSubmit() {
    console.log(this.seller.username);
    console.log(this.seller.password);
   
      if(this.seller.username=="srinivas559" && this.seller.password=="srinivas559")
      {
        this.router.navigate(['Home']);
        alert("login successful");
      }
      else
      {
        alert("Enter the correct username and password");
      }
    }

}
