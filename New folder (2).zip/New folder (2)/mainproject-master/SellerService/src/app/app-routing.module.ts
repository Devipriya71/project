import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DeleteitemComponent} from './deleteitem/deleteitem.component';
import {AdditemComponent} from './additem/additem.component';
import { UpdatestockComponent } from './updatestock/updatestock.component';
import { SellerloginComponent } from './sellerlogin/sellerlogin.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { HomeComponent } from './home/home.component';
import { SellerlogoutComponent } from './sellerlogout/sellerlogout.component';


const routes: Routes = [
  {path:'Home/additem',component:AdditemComponent},
  {path:'Home/deleteitem',component:DeleteitemComponent},
  {path:'Home/updatestock',component:UpdatestockComponent},
  {path:'sellerlogin',component:SellerloginComponent},
  {path:'sellersignup',component:SellersignupComponent},
  { path: 'Home', component: HomeComponent},
  { path: 'sellerlogout', component: SellerlogoutComponent}
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
