import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AddcartComponent } from './addcart/addcart.component';
import { SearchitemsComponent } from './searchitems/searchitems.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DisplaycartComponent } from './displaycart/displaycart.component';
import { UpdatecartComponent } from './updatecart/updatecart.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';
import { BuyerloginComponent } from './buyerlogin/buyerlogin.component';
import { HomeComponent } from './home/home.component';
import {HashLocationStrategy,LocationStrategy} from '@angular/common';
import { BuyerlogoutComponent } from './buyerlogout/buyerlogout.component';


@NgModule({
  declarations: [
    AppComponent,
    AddcartComponent,
    SearchitemsComponent,
    DisplaycartComponent,
    UpdatecartComponent,
    BuyersignupComponent,
    BuyerloginComponent,
    HomeComponent,
    BuyerlogoutComponent
  
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [{provide:LocationStrategy,useClass:HashLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
