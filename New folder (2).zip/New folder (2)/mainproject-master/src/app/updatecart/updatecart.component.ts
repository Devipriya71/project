import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-updatecart',
  templateUrl: './updatecart.component.html',
  styleUrls: ['./updatecart.component.css']
})
export class UpdatecartComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

 
  


  
}
