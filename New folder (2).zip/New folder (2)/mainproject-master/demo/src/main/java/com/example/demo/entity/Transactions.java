package com.example.demo.entity;

import java.util.Date;

import javax.persistence.*;

import org.hibernate.annotations.CreationTimestamp;

@Entity
public class Transactions {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transaction_id;
	@ManyToOne
	private Buyer user;
	
	private String transaction_type;//(Eg. debit or credit)
	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date date_time;
	private float totalcost;

	public float getTotalcost() {
		return totalcost;
	}

	public void setTotalcost(float totalcost) {
		this.totalcost = totalcost;
	}

	public Buyer getUser() {
		return user;
	}

   public void setUser(Buyer user) {
		this.user = user;
	}
    
    public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public String getTransaction_type() {
		return transaction_type;
	}
	public void setTransaction_type(String transaction_type) {
		this.transaction_type = transaction_type;
	}
    public Date getDate_time() {
		return date_time;
	}

	public void setDate_time(Date date_time) {
		this.date_time = date_time;
	}
	
	
	public Transactions()
	{
		System.out.println("Transation Object has been created");
	}
	

	
	public Transactions(int transaction_id, Buyer user, String transaction_type, Date date_time, float totalcost) {
		super();
		this.transaction_id = transaction_id;
		this.user = user;
		this.transaction_type = transaction_type;
		this.date_time = date_time;
		this.totalcost = totalcost;
	}

	@Override
	public String toString() {
		return "Transactions [transaction_id=" + transaction_id + ", user=" + user + ", transaction_type="
				+ transaction_type + ", date_time=" + date_time + ", totalcost=" + totalcost + "]";
	}

	

}
