package com.sellerservice.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sellerservice.entity.Items;

@Repository
public interface ItemsDao extends JpaRepository<Items, Integer> {

	@Query("select i from Items i where i.itemName like concat('%',lower(:searchkey), '%')"  )
	List<Items> searchByName(@Param("searchkey") String searchKey);

	List<Items> findByItemName(String itemName);


}
