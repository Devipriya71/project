package com.example.demo.Entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import org.hibernate.annotations.OnDelete;
import org.hibernate.annotations.OnDeleteAction;

@Entity
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int productid;
	    private String productname;
		private String Manufacturer;
		private String Model;
		//sellerId: 23
		
		@ManyToOne
		@JoinColumn(name="sellerid")
		@OnDelete(action = OnDeleteAction.CASCADE)
		private SellerDetails sdetails;
		
		private float Price;
		private int Quantity;
		
		@ManyToOne
		@JoinColumn(name="category_id")
		@OnDelete(action = OnDeleteAction.CASCADE)
		private SubCategory scategory;
		
		private String decription;
		//picture: 
		public int getProductid() {
			return productid;
		}
		public void setProductid(int productid) {
			this.productid = productid;
		}
		public String getProductname() {
			return productname;
		}
		public void setProductname(String productname) {
			this.productname = productname;
		}
		public String getManufacturer() {
			return Manufacturer;
		}
		public void setManufacturer(String manufacturer) {
			Manufacturer = manufacturer;
		}
		public String getModel() {
			return Model;
		}
		public void setModel(String model) {
			Model = model;
		}
		public SellerDetails getSdetails() {
			return sdetails;
		}
		public void setSdetails(SellerDetails sdetails) {
			this.sdetails = sdetails;
		}
		public float getPrice() {
			return Price;
		}
		public void setPrice(float price) {
			Price = price;
		}
		public int getQuantity() {
			return Quantity;
		}
		public void setQuantity(int quantity) {
			Quantity = quantity;
		}
		public SubCategory getScategory() {
			return scategory;
		}
		public void setScategory(SubCategory scategory) {
			this.scategory = scategory;
		}
		public String getDecription() {
			return decription;
		}
		public void setDecription(String decription) {
			this.decription = decription;
		}
		
		public Product() {
			System.out.println("Product Details Object Has been Created");
			
		}
		
		public Product(int productid, String productName, String manufacturer, String model,
				SellerDetails sdetails, float price, int quantity, SubCategory scatogery, String decription) {
			super();
			this.productid = productid;
			this.productname = productName;
			Manufacturer = manufacturer;
			Model = model;
			this.sdetails = sdetails;
			Price = price;
			Quantity = quantity;
			this.scategory = scatogery;
			this.decription = decription;
		}
		
		
		@Override
		public String toString() {
			return "ProductDetails [productid=" + productid + ", productName=" + productname + ", Manufacturer="
					+ Manufacturer + ", Model=" + Model + ", sdetails=" + sdetails + ", Price=" + Price + ", Quantity="
					+ Quantity + ", scatogery=" + scategory + ", decription=" + decription + "]";
		}
		

}
