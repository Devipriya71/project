package com.example.demo.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Entity.SellerDetails;
import com.example.demo.repositry.SellerDao;
@Service
public class SellerService implements ISellerService
{
	@Autowired
	public SellerDao sdao;

	@Override
	public String addSeller(SellerDetails sdetails)
	{
		sdao.save(sdetails);
		return "\"Seller Account Created\"";
	}

	@Override
	public String updateSeller(Integer sellerid, SellerDetails sdetails)
	{
		SellerDetails sdet=sdao.getOne(sellerid);//getone item
		String usname=sdetails.getUsername();
		 String pass=sdetails.getPassword();
		 String compname=sdetails.getCompanyname();
		 float gstin=sdetails.getGstin();
		 String compdescription=sdetails.getCompanydescription();
		 String postaddres=sdetails.getPostal_address();
		 String site=sdetails.getWebsite();
		 String emailid=sdetails.getEmailid();
		 long contactnumber=sdetails.getContact_number();
		 sdet.setUsername(usname);
		 sdet.setPassword(pass);
		 sdet.setCompanyname(compname);
		 sdet.setGstin(gstin);
		 sdet.setCompanydescription(compdescription);
		 sdet.setPostal_address(postaddres);
		 sdet.setWebsite(site);
		 sdet.setEmailid(emailid);
		 sdet.setContact_number(contactnumber);
		 System.out.println(sdet);
		 sdao.save(sdet);
		return "\"Seller Details Updated\"";
	}

}
