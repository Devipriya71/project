package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Entity.SubCategory;
import com.example.demo.services.ISubCategoryService;


@RestController
@RequestMapping("/subcategory")
public class SubCategoryController {
	
      @Autowired
      private ISubCategoryService isubserv;

	@GetMapping("/getAllSubCatogeries")
	  public List<SubCategory> getAllSubCatogeries()
	   {
		return isubserv.getAllSubCategories();
	   }
	
	@PostMapping("/addAllSubCategories/{category_id}")
	public String addAllSubCategories(@PathVariable int category_id,@RequestBody SubCategory sub)
	{
		return isubserv.addAllSubCategories(category_id,sub);
	}
}
